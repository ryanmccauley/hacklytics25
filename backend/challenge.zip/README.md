# Dilophosaurus Denial Challenge

Welcome to the Jurassic CTF Challenge!

## Overview
In this challenge, you will navigate a misconfigured dinosaur park management system where split flag fragments are hidden among vulnerable endpoints.

## Setup Instructions
1. Clone this repository and navigate to the project directory.
2. Install the required Python packages using:
   ```bash
   pip install -r requirements.txt
   ```
3. Run the server using:
   ```bash
   python server.py
   ```
4. Explore the endpoints:
   - Visit `/dino-data` to retrieve a partial flag hidden in a JSON response.
   - Manipulate URL parameters or session tokens and visit `/dino-logs` to trigger an error that contains the second part of the flag.

## Hints
- Inspect URL parameters and cookies carefully.
- Use an intercepting proxy (e.g., Burp Suite) to modify requests and reveal hidden endpoints.
- Pay attention to the source code comments for dino-themed clues.

Good luck, and may your exploration of the digital dino park be as thrilling as uncovering a rare fossil!

from flask import Flask, request, jsonify, abort
import random

app = Flask(__name__)

# Dummy session store with weak tokens
sessions = {'weaktoken123': 'admin'}

# Fossilized flag fragments
FLAG_PART1 = 'CTF{dilo_fossil_fragment_1}'
FLAG_PART2 = 'CTF{dilo_fossil_fragment_2}'

@app.route('/dino-data')
def dino_data():
    # Simulate a vulnerable endpoint that accepts URL parameters
    # Look carefully in the query string; some parameters might change the output.
    param = request.args.get('param', 'default')
    # Check for a hidden parameter that slightly alters behavior
    if param == 'roar':
        # Normally, this endpoint returns JSON data
        return jsonify({
            "status": "success",
            "message": "As elusive as a Dilophosaurus",
            "flag_fragment": FLAG_PART1
        })
    else:
        return jsonify({
            "status": "success",
            "message": "Welcome to the Dilophosaurus Den. Explore carefully!"
        })

@app.route('/dino-logs')
def dino_logs():
    # Simulate a misconfigured session check that can be manipulated
    token = request.args.get('token', None)
    # If token is manipulated to a specific weak token, trigger a server error with a hidden flag
    if token not in sessions:
        # Simulate an error message that inadvertently reveals flag information
        abort(500, description=f"Critical Error: Reactor failure near T-Rex enclosure. Clue: {FLAG_PART2}")
    # If valid token, return normal logs
    return "Dinosaur telemetry: All systems nominal."

# Custom error handler to display error messages from the logs (simulate leaked debug info)
@app.errorhandler(500)
def internal_error(error):
    # The error description contains a hint with the second part of the flag
    return f"Server Error: {error.description}", 500

if __name__ == '__main__':
    # Debug mode on to simulate verbose logs (but in a real challenge, this would be contained)
    app.run(debug=True)
